from django.contrib import admin
from .models import Userregister

# Register your models here.
class Userregisteradmin(admin.ModelAdmin):
    list_display=['username','email','password']

admin.site.register(Userregister,Userregisteradmin)
