from django.shortcuts import render,redirect
from .models import Userregister
from django.contrib import messages
from .forms import Userregisterform

# Create your views here.
def create(request):
    if request.method=='GET':
        return render(request,'app/index.html')
    else:
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        data=Userregister(username=username,email=email,password=password)
        data.save()
        messages.success(request,'Data Inserted Success')
        return redirect('create')
def read(request):
    data=Userregister.objects.all()
    return render(request,'app/read.html',{'data':data})

def edit(request,pk):
    data=Userregister.objects.get(pk=pk)
    if request.method=='POST':
        data.username=request.POST['username']
        data.email=request.POST['email']
        data.password=request.POST['password']
        data.save()
        return redirect('read')
    else:
        return render(request,'app/edit.html',{'data':data})
    
def delete(request,pk):
    data=Userregister.objects.get(pk=pk)
    if request.method=='POST':
        data.delete()
        return redirect('read')
    else:
        return render(request,'app/delete.html',{'data':data})

    

