from django import forms  
from .models import Userregister 

class Userregisterform(forms.ModelForm):
    class Meta:
        model=Userregister 
        fields=['username','email','password']