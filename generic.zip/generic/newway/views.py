from django.views.generic.edit import CreateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView 
from django.views.generic.edit import UpdateView 
from django.views.generic.edit import DeleteView 
from newway.views import CreateView,ListView,DetailView,UpdateView,DeleteView
from django.urls import reverse
from django.views import View
from .models import Job
class JobCreate(CreateView):
    model=Job
    fields=['jobtitle','jobdescription']
    success_url="/"  
    
class JobList(ListView):
    model=Job #job.objects.all()
    
class JobDetail(DetailView):
    model=Job
    

class JobUpdate(UpdateView):
    model=Job #Job.objects.all()
    fields=["jobtitle","jobdescription"]
    success_url="/newway/joblist"
    
class JobDelete(DeleteView):
    model=Job 
    success_url="/newway/joblist" 
    
    
      
   